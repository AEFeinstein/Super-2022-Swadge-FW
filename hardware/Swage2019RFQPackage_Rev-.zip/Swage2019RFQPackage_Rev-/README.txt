This is a RFQ for MAGFest Swadge Project.

PCB is revD.  This is newer than pictures.  New pictures will be provided.
The BOM is in CSV and contains manufacture notes.

General specifications:
	* Please use 1.6mm 1oz copper 2-sided FR4 PCBs
	* Use RoHS Lead-Free HASL finish.
	* Use Lead-free solder paste.
	* Switch and USB on PCB Back rear may be hand sngoldered.

Test firmware will be provided.

Use same method as other ESP8266 systems to test functionality.  Will need pogo pads on back-of-board to do programming.

If boards fail, will need rework.

Video showing test process will be provided soon.

You may use batteries to test, but DO NOT INSTALL BATTERIES FOR SHIPPING. ONLY SHIP SWADGES WITH BATTERIES REMOVED.  DO NOT SHIP BATTERIES.


